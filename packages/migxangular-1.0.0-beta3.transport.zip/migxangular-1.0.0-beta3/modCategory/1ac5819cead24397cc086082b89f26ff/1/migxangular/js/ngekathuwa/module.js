'use strict';

angular.module('ngEkathuwa', ['ngRoute']);
