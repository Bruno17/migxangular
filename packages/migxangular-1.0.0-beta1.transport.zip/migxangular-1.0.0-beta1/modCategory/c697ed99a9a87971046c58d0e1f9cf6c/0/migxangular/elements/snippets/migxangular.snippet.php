<?php

return include $modx->getOption('migxangular.core_path',null,$modx->getOption('core_path').'components/migxangular/elements/snippets/').'migxangular.php';